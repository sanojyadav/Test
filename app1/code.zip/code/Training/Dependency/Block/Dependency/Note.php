<?php 
declare(strict_types=1);

namespace Training\Dependency\Block\Dependency;
use Magento\Framework\View\Element\Template; 

class Note extends Template
{
	protected $_template = 'Training_Dependency::home/note.phtml';
	
}