<?php
declare(strict_types=1);
namespace Training\DependencyExample\Model;

class Injectable 
{
	
	public function getId(): string
	{
		return "Injectable Class";

	}
	
}