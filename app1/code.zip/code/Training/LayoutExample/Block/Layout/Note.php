<?php 
declare(strict_types=1);

namespace Training\LayoutExample\Block\Layout;
use Magento\Framework\View\Element\Template; 

class Note extends Template
{
	protected $_template = 'Training_LayoutExample::home/note.phtml';
	
}