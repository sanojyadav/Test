<?php 
declare(strict_types=1);
namespace Training\CommonModule\Model;

class Test
{
	public function getName(): string
	{
		return 'Sanoj';
	}
}